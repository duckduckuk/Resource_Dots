# load_average

Show the system 1 minute load average.

![](load_average.png)

# Config

```
[load_average]
command=$SCRIPT_DIR/load_average
interval=10
```
